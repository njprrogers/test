class PicSumImageService {
  constructor() {
    this.picSumListUrl = 'https://picsum.photos/list';
  }

  getImages() {
    return fetch(this.picSumListUrl)
      .then(resp => resp.json())
      .catch((e) => {
        console.log('There has been an error ', e);
      });
  }
}

export default new PicSumImageService();
