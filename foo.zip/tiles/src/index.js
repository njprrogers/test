// import "sanitize.css/sanitize.css";
import React from 'react';
import { render } from 'react-dom';
import { Provider } from 'react-redux';
import { ConnectedRouter } from 'react-router-redux';
import { store, history } from './store';
import ControlsContainer from './containers/ControlsContainer';
import GridContainer from './containers/GridContainer';

import './index.css';

// import { createStore, applyMiddleware, compose } from "redux";
// import { routerMiddleware } from "react-router-redux";
// import thunk from "redux-thunk";
// import createHistory from "history/createBrowserHistory";
// import rootReducer from "./reducers";

// const history = createHistory();

// // const enhancers = [];
// const middleware = [thunk, routerMiddleware(history)];
// const enhancers = compose(applyMiddleware(...middleware));
// const store = createStore(rootReducer, enhancers);
// import "@fortawesome/fontawesome-free-webfonts/css/fa-solid.css";
// import "@fortawesome/fontawesome-free-webfonts/css/fa-brands.css";
// import "@fortawesome/fontawesome-free-webfonts/css/fa-regular.css";
// import "@fortawesome/fontawesome-free-webfonts/css/fontawesome.css";
/* eslint-disable no-undef */
const target = document.querySelector('#root');
/* eslint-disable no-undef */

/* eslint-disable react/jsx-filename-extension */
render(
  <Provider store={store}>
    {/* <ConnectedRouter history={history}> */}
    <div>
      <ControlsContainer />
      <GridContainer />
    </div>
    {/* </ConnectedRouter> */}
  </Provider>,
  target,
);
