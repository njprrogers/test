import React from 'react';
import PropTypes from 'prop-types';

const Controls = ({
  numberOfTiles,
  hasTallTile,
  hasHeroTile,
  handleNumberTilesChange,
  handleTallTileChange,
  handleHeroTileChange,
}) => (
  <form id="controls" className="controls-form">
    <label htmlFor="numberOfTiles">
      Number of tiles:
      <input
        type="number"
        id="numberOfTiles"
        name="number-of-tiles"
        required
        length="10"
        placeholder="Tiles"
        value={numberOfTiles}
        onChange={e => handleNumberTilesChange(e.target.value)}
      />
    </label>
    <label htmlFor="tallTile">
      Tall tile:
      <input
        type="checkbox"
        name="tallTile"
        id="tallTile"
        checked={hasTallTile}
        onChange={e => handleTallTileChange()}
      />
    </label>
    <label htmlFor="heroTile">
      Hero tile:
      <input
        type="checkbox"
        name="heroTile"
        id="heroTile"
        checked={hasHeroTile}
        onChange={e => handleHeroTileChange()}
      />
    </label>
  </form>
);

Controls.propTypes = {
  numberOfTiles: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  hasTallTile: PropTypes.bool.isRequired,
  hasHeroTile: PropTypes.bool.isRequired,
  handleHeroTileChange: PropTypes.func.isRequired,
  handleTallTileChange: PropTypes.func.isRequired,
  handleNumberTilesChange: PropTypes.func.isRequired,
};

export default Controls;
