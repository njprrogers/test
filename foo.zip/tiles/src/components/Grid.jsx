import React, { Component } from 'react';
import { PropTypes } from 'prop-types';
import Loader from './Loader';
import '../css/grid.scss';

class Grid extends Component {
  componentDidMount() {
    const { fetchImages } = this.props;
    fetchImages();
  }

  render() {
    const { isLoading, images, gridTiles } = this.props;

    return isLoading ? (
      <Loader />
    ) : (
      <div className="grid-container">
        {gridTiles.tiles.map(tile => (
          <div className={tile.type}>
            <img src={tile.imageUrl} alt="title" />
          </div>
        ))}
      </div>
    );
  }
}
Grid.propTypes = {
  isLoading: PropTypes.bool.isRequired,
  numberOfTiles: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  fetchImages: PropTypes.bool.isRequired,
  tallTile: PropTypes.bool.isRequired,
  heroTile: PropTypes.bool.isRequired,
  images: PropTypes.array.isRequired,
  gridTiles: PropTypes.array.isRequired,
};
export default Grid;
