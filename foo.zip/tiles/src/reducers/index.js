import {
  UPDATE_NUMBER_OF_TILES,
  TOGGLE_HERO_TILE,
  TOGGLE_TALL_TILE,
  FETCH_IMAGES_SUCCESS,
  FETCH_IMAGES_BEGIN,
  FETCH_IMAGES_FAILURE,
} from '../actions';
import imagesConfig from '../constants/constants';

const initialState = {
  isLoading: false,
  images: [],
  imagesLoadingError: false,
  numberOfTiles: 1,
  hasHeroTile: true,
  hasTallTile: true,
  gridTiles: {
    tiles: [],
  },
};

export default function controlsReducer(state = initialState, action) {
  switch (action.type) {
    case UPDATE_NUMBER_OF_TILES:
      const numberOfTiles = action.numberOfTiles === '' ? '' : parseInt(action.numberOfTiles);
      return {
        ...state,
        numberOfTiles,
        gridTiles: buildGridTiles(state.images, numberOfTiles, state.hasTallTile),
      };

    case TOGGLE_HERO_TILE:
      return {
        ...state,
        hasHeroTile: !state.hasHeroTile,
      };

    case TOGGLE_TALL_TILE:
      const hasTallTile = !state.hasTallTile;
      return {
        ...state,
        hasTallTile: hasTallTile,
        gridTiles: buildGridTiles(state.images, numberOfTiles, hasTallTile),
      };

    case FETCH_IMAGES_BEGIN:
      return {
        ...state,
        isLoading: true,
      };

    case FETCH_IMAGES_SUCCESS:
      return {
        ...state,
        images: action.images,
        isLoading: false,
      };

    case FETCH_IMAGES_FAILURE:
      return {
        ...state,
        imagesLoadingError: action.error,
        isLoading: false,
      };
    default:
      return state;
  }
}

function buildGridTiles(images, numberOfTiles, hasTallTile) {
  console.log('in bujild');
  function isOdd(num) {
    return !!(num % 2);
  }
  let imageUsed = 0;
  const gridTiles = {
    tiles: [],
  };
  if (numberOfTiles === '') {
    return gridTiles;
  }
  function pushImage(size, position) {
    gridTiles.tiles.push({
      type: `${imagesConfig[size].type} ${position}`,
      id: images[imageUsed].id,
      imageUrl: `https://picsum.photos/${imagesConfig[size].width}/${imagesConfig[size].height}?image=${images[imageUsed].id}`,
    });
    imageUsed += 1;
  }

  const oddNumberOfRows = isOdd(numberOfTiles); // means last line is SSS, even means last line is WS
  const numberOfColumns = 3;
  const numberOfTilesPerRow = (2 + 1) / numberOfTiles;


  // work out number of rows and you are laughing
  let numberOfRows = Math.floor(numberOfTiles / 2);
  if (hasTallTile) {
    numberOfRows += 1;
  }

  for (let i = 0; i < numberOfRows; i += 1) {
    console.log('intheloop', oddNumberOfRows);
    const currentRow = i + 1;
    const lastRow = currentRow === numberOfRows;

    if (hasTallTile && currentRow < 4) {
      if (currentRow === 1) {
        pushImage('wide');
        pushImage('tall');
      } else if (isOdd(i) === false) {
        pushImage('wide');
      } else {
        pushImage('single');
        pushImage('single');
      }
      continue;
    }

    // Not last row
    if (lastRow && oddNumberOfRows) {
      pushImage('single');
      pushImage('single');
      pushImage('single');
    } else if (!isOdd(i)) {
      pushImage('wide', 'left');
      pushImage('single');
    } else {
      pushImage('single');
      pushImage('wide', 'right');
    }
  }

  return gridTiles;

  // const gridTiles = {
  //   // rows: [
  //   //   {
  //   tiles: [
  //     // {
  //     //   type: 'hero',
  //     //   id: state.images[6].id,
  //     //   imageUrl: `https://picsum.photos/900/300?image=${state.images[0].id}`,
  //     // },
  //     {
  //       type: "medium",
  //       id: state.images[0].id,
  //       imageUrl: `https://picsum.photos/600/300?image=${state.images[0].id}`
  //     },
  //     // {
  //     //   type: 'tall has-hero',
  //     //   id: state.images[1].id,
  //     //   imageUrl: `https://picsum.photos/300/900?image=${state.images[1].id}`,
  //     // },
  //     {
  //       type: "single",
  //       id: state.images[2].id,
  //       imageUrl: `https://picsum.photos/300/300?image=${state.images[2].id}`
  //     },
  //     {
  //       type: "single",
  //       id: state.images[3].id,
  //       imageUrl: `https://picsum.photos/300/300?image=${state.images[3].id}`
  //     },
  //     {
  //       type: "medium right",
  //       id: state.images[4].id,
  //       imageUrl: `https://picsum.photos/600/300?image=${state.images[4].id}`
  //     },
  //     {
  //       type: "single",
  //       id: state.images[4].id,
  //       imageUrl: `https://picsum.photos/300/300?image=${state.images[4].id}`
  //     }
  //   ]
  //   }
  // ]
  // };
}
