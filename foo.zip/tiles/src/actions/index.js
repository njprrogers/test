import picSumImageService from '../services/picsum.service';

export const UPDATE_NUMBER_OF_TILES = 'UPDATE_NUMBER_OF_TILES';
export function updateNumberOfTiles(numberOfTiles) {
  return {
    type: UPDATE_NUMBER_OF_TILES,
    numberOfTiles,
  };
}
export const TOGGLE_HERO_TILE = 'TOGGLE_HERO_TILE';
export function toggleHeroTile(hasHeroTile) {
  return {
    type: TOGGLE_HERO_TILE,
    hasHeroTile,
  };
}
export const TOGGLE_TALL_TILE = 'TOGGLE_TALL_TILE';
export function toggleTallTile(hasTallTile) {
  return {
    type: TOGGLE_TALL_TILE,
    hasTallTile,
  };
}
export const FETCH_IMAGES_BEGIN = 'FETCH_IMAGES_BEGIN';
export const FETCH_IMAGES_SUCCESS = 'FETCH_IMAGES_SUCCESS';
export function fetchImagesSuccess(images) {
  return {
    type: FETCH_IMAGES_SUCCESS,
    images,
  };
}
export const FETCH_IMAGES_FAILURE = 'FETCH_IMAGES_FAILURE';
export function fetchImagesFailure(error) {
  return {
    type: FETCH_IMAGES_SUCCESS,
    error,
  };
}

export const fetchImages = () => (dispatch) => {
  dispatch({
    type: FETCH_IMAGES_BEGIN,
  });

  return picSumImageService
    .getImages()
    .then((response) => {
      dispatch(fetchImagesSuccess(response));
      dispatch(updateNumberOfTiles(1));
    })
    .catch((error) => {
      dispatch(fetchImagesFailure(error));
    });
};
