const imagesConfig = {
  url: 'https://picsum.photos/list',
  single: {
    type: 'single',
    height: 300,
    width: 300,
  },
  wide: {
    type: 'wide',
    height: 300,
    width: 600,
  },
  tall: {
    type: 'tall',
    height: 900,
    width: 300,
  },
  hero: {
    type: 'hero',
    height: 300,
    width: 900,
  },
};

export default imagesConfig;
