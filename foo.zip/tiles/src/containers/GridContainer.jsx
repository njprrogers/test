import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import Grid from '../components/Grid';
import { fetchImages } from '../actions';

const mapStateToProps = state => ({
  isLoading: state.isLoading,
  numberOfTiles: state.numberOfTiles,
  tallTile: state.hasTallTile,
  heroTile: state.hasHeroImage,
  images: state.images,
  gridTiles: state.gridTiles,
});

const mapDispatchToProps = dispatch => bindActionCreators(
  {
    fetchImages,
  },
  dispatch,
);

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(Grid);
