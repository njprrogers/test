import { connect } from "react-redux";
import Controls from "../components/Controls";
import {
  toggleHeroTile,
  updateNumberOfTiles,
  toggleTallTile
} from "../actions";

const mapStateToProps = state => ({
  isLoading: state.isLoading,
  numberOfTiles: state.numberOfTiles,
  hasHeroTile: state.hasHeroTile,
  hasTallTile: state.hasTallTile
});

const mapDispatchToProps = dispatch => {
  return {
    handleNumberTilesChange: numberOfTiles =>
      dispatch(updateNumberOfTiles(numberOfTiles)),
    handleHeroTileChange: () => dispatch(toggleHeroTile()),
    handleTallTileChange: () => dispatch(toggleTallTile())
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Controls);
